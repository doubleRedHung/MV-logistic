% This script is a toy example that
% demos how to use this package to fit a MV-logistic model.


% We first generate 2 groups of training samples.
row_dim = 10;
col_dim = 10;
bias = 1;
training_size = 300;
x_train = cat(3, randn([row_dim, col_dim, training_size]) - bias, randn([row_dim, col_dim, training_size]) + bias);
y = [zeros(training_size, 1); ones(training_size, 1)];

% Then we fit the model.
penalty = 1;
model = mvlogistic_fit(x_train, y, penalty);

% And we can use the model to make predictions on the testing set.
testing_size = 5;
x_test = cat(3, randn([row_dim, col_dim, testing_size]) - bias, randn([row_dim, col_dim, testing_size]) + bias);
label_mvlogistic = mvlogistic_predict(x_test, model)

% Compare with Matlab's built-in logistic regression function,
% which fails to work if the training_size is small.
logistic_model = mnrfit(reshape(x_train, [], size(x_train, 3))', bsxfun(@eq, y, 0:1));
p_hat = mnrval(logistic_model, reshape(x_test, [], size(x_test, 3))');
[val label_logistic] = max(p_hat, [], 2);
label_logistic = label_logistic - 1