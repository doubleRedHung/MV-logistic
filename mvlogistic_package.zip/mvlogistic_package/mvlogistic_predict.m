function [label, predicted_probability] = mvlogistic_predict(x_test, model)
% Usage: [label, predicted_probability] = mvlogistic_predict(x_test, model)
%
% Input --  x_test: testing matrices
%           model:  the structure returned by mvlogistic_fit
%
% Output -- label: predicted label.
%           predicted_probability: predicted probability
%          

[p, q, n] = size(x_test);
if model.standardize
  x_test = bsxfun(@rdivide, bsxfun(@minus, x_test, model.mean), model.std);
end
log_odds = model.parameters.gamma + ...
   kron(model.parameters.beta, model.parameters.alpha)' * reshape(x_test, [], n);
log_odds = log_odds';
label = log_odds > 0;
predicted_probability = 1./(1+exp(-log_odds));

end

