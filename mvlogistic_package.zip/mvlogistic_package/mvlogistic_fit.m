function model = mvlogistic_fit(x, y, penalty, fixed_idx, penalize_intercept, standardize, tol, max_iter)
% The function for fitting MV logistic model
%   log(odds ratio) = gamma + alpha' * x * beta
% 
% Usage: 
% model = mvlogistic_fit(x, y, penalty, fixed_idx, penalize_intercept, standardize, tol, max_iter)
%
%
% Input --- x: training matrices of size p x q x n, where
%              the i_th sample x(:, :, i) is a p x q matrix
%           y: binary response in {0, 1}, an n x 1 vector, where n
%              is the sample size.
%              
%       Optional arguments:
%           penalty: default value = 0  
%           fixed_idx: the index which alpha is fixed, 
%                such that model.parameters.alpha(fixed_idx) = 1.
%                default = 1
%           penalize_intercept: default = true
%           stardardize: stardardize the covariates before fitting the model
%                        default = false
%           tol: tolerance, 
%                default = 1e-4
%           max_iter: maximum iterations
%                default = 30
%
%
% Output --- model: a structure contains,
%            model.parameters: the estimated parameter estimates
%            model.cov_matrix: the estimated covariance matrix
%

if nargin < 8
    max_iter = 30;
end
if nargin < 7
    tol = 1e-4;
end
if nargin < 6
    standardize = false;
end
if nargin < 5
    penalize_intercept = true;
end
if nargin < 4
    fixed_idx = 1;
end
if nargin < 3
    penalty = 0;
end
if nargin < 2
    error('Usage: model = mvlogistic_fit(x, y, penalty, fixed_idx, penalize_intercept, standardize, tol, max_iter)')
end

[p, q, n] = size(x);
model.standardize = standardize;
if standardize
    model.mean = mean(x, 3);
    model.std = std(x, 0, 3);
    x = bsxfun(@rdivide, bsxfun(@minus, x, model.mean), model.std);
end
x = reshape(x, [], n)';



y = double(y);
iter = 1;
gamma = 0;
alpha_star = zeros(p-1, 1);
beta = zeros(q, 1);

kron_beta_alpha = kron(beta, [alpha_star(1:(fixed_idx-1)); 1 ;alpha_star(fixed_idx: end)]);
C = [eye(fixed_idx - 1), zeros(fixed_idx - 1, p - fixed_idx); ...
    zeros(1, p-1); ...
    zeros(p-fixed_idx, fixed_idx-1), eye(p-fixed_idx)];

diff_norm = 1;
length_parameters = max([1, p+q]);

while (diff_norm > tol && iter <= max_iter)
    if iter == 1
        penalty_magnification_rate = 10;
    else
        penalty_magnification_rate = 1;
    end
    lam = penalty * penalty_magnification_rate;
    gamma_old = gamma;
    kron_beta_alpha_old = kron_beta_alpha;
    
    exp_term = -gamma - x*kron_beta_alpha;
    
    Pi = (1 + exp(exp_term)).^(-1);
    V = Pi.*(1-Pi);
    
    X = [ones(n, 1), x*[kron(beta, C), ...
        kron(eye(q), [alpha_star(1:(fixed_idx-1)); 1; alpha_star(fixed_idx:end)])]];
    
    hessian = - X' * diag(V) * X;
    theta = [gamma; alpha_star; beta] - ...
        (hessian - ...
        lam*blkdiag(penalize_intercept, eye(length_parameters - 1))) \ ...
        (X' * (y - Pi) - lam * [penalize_intercept * gamma; alpha_star; beta]);
    
    gamma = theta(1);
    alpha_star = theta(2: p);  
    beta = theta(p+1: p+q); 
    alpha = [alpha_star(1:(fixed_idx-1)); 1; alpha_star(fixed_idx: end)];
    kron_beta_alpha = kron(beta, alpha);
    
    diff_norm = (norm([gamma; kron_beta_alpha] - [gamma_old; kron_beta_alpha_old])) / norm([gamma_old; kron_beta_alpha_old]);
    iter = iter + 1;
end
model.parameters.gamma = gamma;
model.parameters.alpha = [alpha_star(1:fixed_idx-1); 1; alpha_star(fixed_idx:end)];
model.parameters.beta = beta;


model.cov_matrix = - (hessian - lam*blkdiag(penalize_intercept, eye(length_parameters - 1))) \ ...
    hessian / (hessian - lam*blkdiag(penalize_intercept, eye(length_parameters - 1)));


end